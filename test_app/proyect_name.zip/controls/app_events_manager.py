

"""
NOTE: This is a global event that all events will be refer to this event_manager

Exemple:

is_gloval = 'hello world'     #: Global scope

def event_2933(data):
     global is_local          #: Set a local scope to global

     is_local = 'hello world'
"""

from builder.app_manager import got_to_screen



def event_4444(data):
    got_to_screen(to_screen='main_screen' ,style='ring' ,time_style=0.8 )
    # print('demo',data)

def event_2222(data):
    got_to_screen(to_screen='screen_2' ,style='ring' ,time_style=0.8 )
    # print('demo',data)

def event_2934(data):
    got_to_screen(to_screen='screen_1' ,style='ring' ,time_style=0.8 )
    # print('demo',data)

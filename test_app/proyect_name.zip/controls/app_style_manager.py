#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles = {

    "_2921": {
        "alignment": {"x":0,"y":0},
        "gradient": {"colors":["Black","Teal","red","yellow"],"tile_mode":"clamp","begin":{"x":0,"y":1},"end":{"x":0,"y":-1},"type":"linear"},
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "padding": {"l":0,"t":0,"r":0,"b":0},
        "tooltip": "Column: 1"
    },
    "_4444": {
        "alignment": {"x":0,"y":0},
        "gradient": {"colors":["Teal","red","yellow"],"tile_mode":"clamp","begin":{"x":0,"y":1},"end":{"x":0,"y":-1},"type":"linear"},
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "padding": {"l":0,"t":0,"r":0,"b":0},
        "tooltip": "Column: 1"
    },
    "aaaa": {
            "width":"240",
            "bgcolor":"black38",
            "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
    },
    "_2222": {
        "alignment": {"x":0,"y":0},
        "gradient": {"colors":["yellow","Cyan","red"],"tile_mode":"clamp","begin":{"x":0,"y":1},"end":{"x":0,"y":-1},"type":"linear"},
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "padding": {"l":0,"t":0,"r":0,"b":0},
        "tooltip": "Column: 1"
    },
    "_2922": {
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_2925": {
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "on_hover": "false",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text: 2"
    },
    "_2926": {
        "size": "10",
        "tooltip": "Text",
        "value": "Ready to make your first app!!nBegin your journey..."
    },
    "_2929": {
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "on_hover": "false",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text Field: 3"
    },
    "_2930": {
        "border_color": "white",
        "border_radius": {"bl":30,"br":30,"tl":30,"tr":30},
        "content_padding": {"l":16,"t":16,"r":16,"b":16},
        "cursor_height": "20",
        "focused_border_color": "red",
        "height": "32",
        "label": "what's your name ?",
        "text_size": "12",
        "tooltip": "TextField",
        "width": "240"
    },
    "_2933": {
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "on_hover": "false",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Elevated Button: 4"
    },
    "_2934": {
        "height": "28",
        "text": "Accept",
        "tooltip": "ElevatedButton"
    }
}
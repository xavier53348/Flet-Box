
```python

class NameApp(ft.UserControl):
    # globalVar='Erase this test'

    def __init__(self,data='Erase this test'):
        super().__init__()
        # self.title='data'
        self.title=data

    def build(self):
        Drop_NameApp=ft.Container(

```

```python
{

    "_135": {
            'width': '240',
            'height':'320',
            'bgcolor':"#44CCCC00",
            'alignment': ft.alignment.center,
            'border_radius':{"bl":'30',"br":'30',"tl":'30',"tr":'30'}
            },
}
```
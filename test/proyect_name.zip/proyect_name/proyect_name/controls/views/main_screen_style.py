#: THIS IS NOT JSON FILE IT'S PYTHON DICTIONARY

styles={
    "_2942": {
        # "WIDGET_NAME": "CONTAINER_COLUMN",
        "alignment": {"x":0,"y":0},
        "bgcolor": ",0.08",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "border_radius": {"bl":24,"br":24,"tl":24,"tr":24},
        "gradient": {"colors":["BLue","Purple","Red","Orange"],"tile_mode":"clamp","begin":{"x":0,"y":1},"end":{"x":0,"y":-1},"type":"linear"},
        "height": "450",
        "ink": "true",
        "ink_color": "yellow",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "shadow": {"spread_radius":0,"blur_radius":24,"color":"black","offset":{"x":0,"y":0},"blur_style":"outer"},
        "tooltip": "Column: 1",
        "width": "340"
    },
    "_2943": {
        # "WIDGET_NAME": "CONTENT_COLUMN",
        "horizontal_alignment": "center",
        "scroll": "ALWAYS"
    },
    "_2946": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text: 2"
    },
    "_2947": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": "10",
        "tooltip": "Text",
        "value": "nReady to make your first app!!nBegin your journey...n"
    },
    "_2950": {
        # "WIDGET_NAME": "CONTAINER_TEXTFIELD",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text Field: 3"
    },
    "_2951": {
        # "WIDGET_NAME": "CONTENT_TEXTFIELD",
        "border_color": "white",
        "border_radius": {"bl":30,"br":30,"tl":30,"tr":30},
        "content_padding": {"l":16,"t":16,"r":16,"b":16},
        "cursor_height": "20",
        "focused_border_color": "red",
        "height": "32",
        "label": "what's your name ?",
        "text_size": "12",
        "tooltip": "TextField",
        "width": "240"
    },
    "_2954": {
        # "WIDGET_NAME": "CONTAINER_TEXTFIELD",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text Field: 4"
    },
    "_2955": {
        # "WIDGET_NAME": "CONTENT_TEXTFIELD",
        "border_color": "white",
        "border_radius": {"bl":30,"br":30,"tl":30,"tr":30},
        "content_padding": {"l":16,"t":16,"r":16,"b":16},
        "cursor_height": "20",
        "focused_border_color": "red",
        "height": "32",
        "label": "what's your name ?",
        "text_size": "12",
        "tooltip": "TextField",
        "width": "240"
    },
    "_2958": {
        # "WIDGET_NAME": "CONTAINER_TEXT",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text: 5"
    },
    "_2959": {
        # "WIDGET_NAME": "CONTENT_TEXT",
        "size": "10",
        "tooltip": "Text",
        "value": "nReady to make your first app!!nBegin your journey...n"
    },
    "_2962": {
        # "WIDGET_NAME": "CONTAINER_ROW",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "cyan",
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Row: 6"
    },
    "_2963": {
        # "WIDGET_NAME": "CONTENT_ROW",
        "scroll": "ALWAYS"
    },
    "_2966": {
        # "WIDGET_NAME": "CONTAINER_ELEVATEDBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Elevated Button: 7"
    },
    "_2967": {
        # "WIDGET_NAME": "CONTENT_ELEVATEDBUTTON",
        "height": "28",
        "text": "Accept",
        "tooltip": "ElevatedButton"
    },
    "_2970": {
        # "WIDGET_NAME": "CONTAINER_TEXTBUTTON",
        "alignment": {"x":0,"y":0},
        "bgcolor": "transparent",
        "border": {"l":{"w":0,"c":"transparent"},"t":{"w":0,"c":"transparent"},"r":{"w":0,"c":"transparent"},"b":{"w":0,"c":"transparent"}},
        "ink": "true",
        "ink_color": "red",
        "margin": {"l":0,"t":0,"r":0,"b":0},
        "padding": {"l":6,"t":6,"r":6,"b":6},
        "tooltip": "Text Button: 8"
    },
    "_2971": {
        # "WIDGET_NAME": "CONTENT_TEXTBUTTON",
        "height": "28",
        "text": "Accept",
        "tooltip": "TextButton"
    }
}
# A flet-box Flet app

An example of a counter Flet app.

To run the app:

```
flet run [app_directory]

my_package/
├── pyproject.toml
├── README.md
├── my_package/
│   ├── __init__.py
│   └── module.py

```